#!/bin/bash

APP_NAME="dns-scanner"
VERSION="1.0.0"
OUTPUT_DIR="build"

mkdir -p "$OUTPUT_DIR"

echo "Building $APP_NAME v$VERSION ..."
echo ""

# Linux amd64
echo "  → linux/amd64"
GOOS=linux GOARCH=amd64 go build -ldflags="-s -w" -o "$OUTPUT_DIR/${APP_NAME}-linux-amd64" .

# Linux arm64
echo "  → linux/arm64"
GOOS=linux GOARCH=arm64 go build -ldflags="-s -w" -o "$OUTPUT_DIR/${APP_NAME}-linux-arm64" .

# Windows amd64
echo "  → windows/amd64"
GOOS=windows GOARCH=amd64 go build -ldflags="-s -w" -o "$OUTPUT_DIR/${APP_NAME}-windows-amd64.exe" .

# Windows arm64
echo "  → windows/arm64"
GOOS=windows GOARCH=arm64 go build -ldflags="-s -w" -o "$OUTPUT_DIR/${APP_NAME}-windows-arm64.exe" .

# Android arm64 (termux compatible)
echo "  → android/arm64"
GOOS=android GOARCH=arm64 go build -ldflags="-s -w" -o "$OUTPUT_DIR/${APP_NAME}-android-arm64" .

# Android amd64 (emulator)
echo "  → android/amd64"
GOOS=android GOARCH=amd64 go build -ldflags="-s -w" -o "$OUTPUT_DIR/${APP_NAME}-android-amd64" .

echo ""
echo "Build complete! Files in ./$OUTPUT_DIR/"
ls -lh "$OUTPUT_DIR/"
