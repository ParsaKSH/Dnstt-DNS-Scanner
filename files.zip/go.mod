module github.com/digitalvps/dns-scanner

go 1.21
