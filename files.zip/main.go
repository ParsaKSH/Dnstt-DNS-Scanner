package main

import (
	"bufio"
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"net"
	"os"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type Config struct {
	ListFile       string  `json:"list_file"`
	DomainListFile string  `json:"domain_list_file"`
	WorksFile      string  `json:"works_file"`
	OutputFile     string  `json:"output_file"`
	ConfigFile     string  `json:"-"`
	Concurrency    int     `json:"concurrency"`
	TimeoutMs      int     `json:"timeout_ms"`
	PassPercent    float64 `json:"pass_percent"`
	QueryPerSec    int     `json:"query_per_sec"`
}

func defaultConfig() Config {
	return Config{
		ListFile:       "list.txt",
		DomainListFile: "domainlist.txt",
		WorksFile:      "works.txt",
		OutputFile:     "output.txt",
		ConfigFile:     "config.json",
		Concurrency:    50,
		TimeoutMs:      3000,
		PassPercent:    80.0,
		QueryPerSec:    20,
	}
}

func loadConfig() Config {
	cfg := defaultConfig()

	// Define flags
	configFile := flag.String("config", cfg.ConfigFile, "Path to config.json")
	listFile := flag.String("list", "", "Path to DNS list file")
	domainFile := flag.String("domains", "", "Path to domain list file")
	worksFile := flag.String("works", "", "Path to working DNS output file")
	outputFile := flag.String("output", "", "Path to final output file")
	concurrency := flag.Int("concurrency", 0, "Number of concurrent workers")
	timeoutMs := flag.Int("timeout", 0, "DNS query timeout in milliseconds")
	passPercent := flag.Float64("pass-percent", 0, "Minimum pass percentage (0-100)")
	queryPerSec := flag.Int("qps", 0, "Queries per second rate limit")
	flag.Parse()

	// Load config.json if exists
	if data, err := os.ReadFile(*configFile); err == nil {
		if err := json.Unmarshal(data, &cfg); err != nil {
			log.Printf("[WARN] Failed to parse %s: %v, using defaults", *configFile, err)
		} else {
			log.Printf("[INFO] Loaded config from %s", *configFile)
		}
	}

	// CLI flags override config.json
	if *listFile != "" {
		cfg.ListFile = *listFile
	}
	if *domainFile != "" {
		cfg.DomainListFile = *domainFile
	}
	if *worksFile != "" {
		cfg.WorksFile = *worksFile
	}
	if *outputFile != "" {
		cfg.OutputFile = *outputFile
	}
	if *concurrency > 0 {
		cfg.Concurrency = *concurrency
	}
	if *timeoutMs > 0 {
		cfg.TimeoutMs = *timeoutMs
	}
	if *passPercent > 0 {
		cfg.PassPercent = *passPercent
	}
	if *queryPerSec > 0 {
		cfg.QueryPerSec = *queryPerSec
	}

	return cfg
}

func readLines(path string) ([]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var lines []string
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" && !strings.HasPrefix(line, "#") {
			lines = append(lines, line)
		}
	}
	return lines, scanner.Err()
}

func writeLines(path string, lines []string) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()

	w := bufio.NewWriter(f)
	for _, line := range lines {
		fmt.Fprintln(w, line)
	}
	return w.Flush()
}

// queryDNS sends a DNS A record query for domain using the given DNS server IP.
func queryDNS(dnsIP, domain string, timeout time.Duration) bool {
	resolver := &net.Resolver{
		PreferGo: true,
		Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
			d := net.Dialer{Timeout: timeout}
			return d.DialContext(ctx, "udp", net.JoinHostPort(dnsIP, "53"))
		},
	}
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()

	addrs, err := resolver.LookupHost(ctx, domain)
	return err == nil && len(addrs) > 0
}

// Phase 1: Check which DNS servers respond to at least one query.
func phase1(cfg Config, dnsList []string, testDomain string) []string {
	fmt.Println("\n╔══════════════════════════════════════════════════╗")
	fmt.Println("║          PHASE 1: DNS Liveness Check             ║")
	fmt.Println("╚══════════════════════════════════════════════════╝")
	fmt.Printf("  Test domain : %s\n", testDomain)
	fmt.Printf("  DNS servers : %d\n", len(dnsList))
	fmt.Printf("  Concurrency : %d\n", cfg.Concurrency)
	fmt.Printf("  Timeout     : %dms\n\n", cfg.TimeoutMs)

	timeout := time.Duration(cfg.TimeoutMs) * time.Millisecond
	var working []string
	var mu sync.Mutex
	var checked int64
	total := int64(len(dnsList))

	sem := make(chan struct{}, cfg.Concurrency)
	var wg sync.WaitGroup

	// Progress ticker
	done := make(chan struct{})
	go func() {
		ticker := time.NewTicker(500 * time.Millisecond)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				c := atomic.LoadInt64(&checked)
				mu.Lock()
				w := len(working)
				mu.Unlock()
				fmt.Printf("\r  [Phase 1] %d/%d checked | %d working", c, total, w)
			case <-done:
				return
			}
		}
	}()

	for _, dns := range dnsList {
		wg.Add(1)
		sem <- struct{}{}
		go func(ip string) {
			defer wg.Done()
			defer func() { <-sem }()

			if queryDNS(ip, testDomain, timeout) {
				mu.Lock()
				working = append(working, ip)
				mu.Unlock()
			}
			atomic.AddInt64(&checked, 1)
		}(dns)
	}

	wg.Wait()
	close(done)

	fmt.Printf("\r  [Phase 1] %d/%d checked | %d working\n", total, total, len(working))
	fmt.Printf("\n  ✓ %d DNS servers are alive. Saved to %s\n", len(working), cfg.WorksFile)

	return working
}

// Phase 2: Stress-test working DNS servers with all domains.
func phase2(cfg Config, workingDNS []string, domains []string) []string {
	fmt.Println("\n╔══════════════════════════════════════════════════╗")
	fmt.Println("║        PHASE 2: DNS Stress Test                  ║")
	fmt.Println("╚══════════════════════════════════════════════════╝")
	fmt.Printf("  Working DNS : %d\n", len(workingDNS))
	fmt.Printf("  Domains     : %d\n", len(domains))
	fmt.Printf("  QPS limit   : %d\n", cfg.QueryPerSec)
	fmt.Printf("  Pass %%      : %.1f%%\n", cfg.PassPercent)
	fmt.Printf("  Timeout     : %dms\n\n", cfg.TimeoutMs)

	timeout := time.Duration(cfg.TimeoutMs) * time.Millisecond
	totalDomains := len(domains)

	type dnsResult struct {
		ip      string
		success int64
		total   int64
	}

	results := make([]dnsResult, len(workingDNS))
	for i, ip := range workingDNS {
		results[i] = dnsResult{ip: ip, total: int64(totalDomains)}
	}

	// Rate limiter: cfg.QueryPerSec tokens per second
	rateLimiter := make(chan struct{}, cfg.QueryPerSec)
	go func() {
		interval := time.Second / time.Duration(cfg.QueryPerSec)
		ticker := time.NewTicker(interval)
		defer ticker.Stop()
		for range ticker.C {
			select {
			case rateLimiter <- struct{}{}:
			default:
			}
		}
	}()

	// Pre-fill rate limiter
	for i := 0; i < cfg.QueryPerSec; i++ {
		rateLimiter <- struct{}{}
	}

	var totalChecked int64
	totalQueries := int64(len(workingDNS)) * int64(totalDomains)

	// Progress ticker
	done := make(chan struct{})
	go func() {
		ticker := time.NewTicker(500 * time.Millisecond)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				c := atomic.LoadInt64(&totalChecked)
				pct := float64(0)
				if totalQueries > 0 {
					pct = float64(c) / float64(totalQueries) * 100
				}
				fmt.Printf("\r  [Phase 2] %d/%d queries (%.1f%%)", c, totalQueries, pct)
			case <-done:
				return
			}
		}
	}()

	sem := make(chan struct{}, cfg.Concurrency)
	var wg sync.WaitGroup

	for i := range results {
		for _, domain := range domains {
			wg.Add(1)
			<-rateLimiter
			sem <- struct{}{}
			go func(idx int, dom string) {
				defer wg.Done()
				defer func() { <-sem }()

				if queryDNS(results[idx].ip, dom, timeout) {
					atomic.AddInt64(&results[idx].success, 1)
				}
				atomic.AddInt64(&totalChecked, 1)
			}(i, domain)
		}
	}

	wg.Wait()
	close(done)

	c := atomic.LoadInt64(&totalChecked)
	fmt.Printf("\r  [Phase 2] %d/%d queries (100.0%%)\n\n", c, totalQueries)

	// Evaluate results
	threshold := cfg.PassPercent / 100.0
	var passed []string

	fmt.Println("  ┌──────────────────┬─────────┬─────────┬────────┬────────┐")
	fmt.Println("  │ DNS Server       │ Success │  Total  │   %    │ Status │")
	fmt.Println("  ├──────────────────┼─────────┼─────────┼────────┼────────┤")

	for _, r := range results {
		succ := atomic.LoadInt64(&r.success)
		pct := float64(succ) / float64(r.total) * 100
		status := "FAIL"
		if pct >= cfg.PassPercent {
			status = "PASS"
			passed = append(passed, r.ip)
		}
		fmt.Printf("  │ %-16s │ %7d │ %7d │ %5.1f%% │ %-6s │\n",
			r.ip, succ, r.total, pct, status)
	}

	fmt.Println("  └──────────────────┴─────────┴─────────┴────────┴────────┘")
	fmt.Printf("\n  ✓ %d DNS servers passed (≥%.1f%% threshold). Saved to %s\n",
		len(passed), cfg.PassPercent, cfg.OutputFile)

	_ = threshold // used above in comparison
	return passed
}

func main() {
	startTime := time.Now()

	cfg := loadConfig()

	fmt.Println("┌──────────────────────────────────────────────────┐")
	fmt.Println("│           DigitalVPS DNS Scanner v1.0            │")
	fmt.Println("└──────────────────────────────────────────────────┘")

	// Read DNS list
	dnsList, err := readLines(cfg.ListFile)
	if err != nil {
		log.Fatalf("[FATAL] Cannot read DNS list %s: %v", cfg.ListFile, err)
	}
	if len(dnsList) == 0 {
		log.Fatal("[FATAL] DNS list is empty")
	}

	// Read domain list
	domains, err := readLines(cfg.DomainListFile)
	if err != nil {
		log.Fatalf("[FATAL] Cannot read domain list %s: %v", cfg.DomainListFile, err)
	}
	if len(domains) == 0 {
		log.Fatal("[FATAL] Domain list is empty")
	}

	fmt.Printf("  DNS servers loaded  : %d\n", len(dnsList))
	fmt.Printf("  Domains loaded      : %d\n", len(domains))

	// --- Phase 1 ---
	working := phase1(cfg, dnsList, domains[0])
	if err := writeLines(cfg.WorksFile, working); err != nil {
		log.Fatalf("[FATAL] Cannot write %s: %v", cfg.WorksFile, err)
	}

	if len(working) == 0 {
		fmt.Println("\n  [!] No working DNS servers found. Exiting.")
		return
	}

	// --- Phase 2 ---
	passed := phase2(cfg, working, domains)
	if err := writeLines(cfg.OutputFile, passed); err != nil {
		log.Fatalf("[FATAL] Cannot write %s: %v", cfg.OutputFile, err)
	}

	elapsed := time.Since(startTime)
	fmt.Printf("\n  Total time: %s\n", elapsed.Round(time.Millisecond))
	fmt.Println("  Done!")
}
